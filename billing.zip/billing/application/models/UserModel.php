<?php

class UserModel extends CI_Model
{
    public function getUsers()
    {
        $query = $this->db->query("select * from user");
        return $query->result();
    }
    public function saveData($name,$email,$pwd)
    {
        return $this->db->query("insert into user values(NULL,'$name','$email','$pwd')");
    }
}