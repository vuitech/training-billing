<?php

class Hello extends CI_Controller
{
    public function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->helper("url");
        $this->load->model("UserModel");
    }
    public function index()
    {
        //echo "This is my first CodeIgniter Application....";
        $this->load->view("newuserlist");
    }
    public function showUsers()
    {
        $result['data']=$this->UserModel->getUsers();
        //$this->load->view("users",$result);
        //echo $result['data'];
        $table = "<table width='100%'><tr><th>Uid</th><th>Uname</th><th>email</th><th>Password</th></tr>";
        foreach($result['data'] as $row)
        {
           $table .="<tr><td>$row->uid</td><td>$row->name</td><td>$row->email</td><td>$row->password</td></tr>";
        }
        $table .="</table>";
        echo $table;
    }
    public function saveData()
    {
        $nm = $this->input->post('nm');
        $email = $this->input->post('email');
        $pwd = $this->input->post('pwd');
        $this->UserModel->saveData($nm,$email,$pwd);
        //$this->showUsers();
    }
}
