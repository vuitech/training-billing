<html>
    <head>
        <title>First Page</title>
    </head>
    <body>
        <h1>Users</h1>
        <?php
        foreach($data as $row)
        {
            echo $row->uid," ",$row->name," ", $row->email," ",$row->password,"<br/>";
        }
        ?>
        
        <h1>Insert User Data</h1>
        <form action="http://localhost/billing/index.php/Hello/saveData" method="post">
        <table>
            <tr>
                <td>Name</td>
                <td><input type="text" name="nm"/></td>
            </tr>
            <tr>
                <td>email</td>
                <td><input type="text" name="email"/></td>
            </tr>
            <tr>
                <td>password</td>
                <td><input type="text" name="pwd"/></td>
            </tr>
            <tr>
                <td colspan="2">
                    <input type="submit" value="submit"/>
                </td>
            </tr>
        </table>
        </form>
    </body>
</html>
