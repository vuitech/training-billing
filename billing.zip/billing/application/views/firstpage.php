<html>
    <head>
        <title>First Page</title>
    </head>
    <body>
        <h1>This is my first view page in codeigniter</h1>
    </body>
</html>