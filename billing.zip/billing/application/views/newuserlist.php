<html>
    <head>
        <title>First Page</title>
        <script src="../../assets/jquery/jquery-3.5.1.min.js"></script>
    </head>
    <body>
        <h1>Users</h1>
        <div id="userlist">
            
        </div>
        <h1>Insert User Data</h1>

        <form id="frmAddUser" action="<?=base_url()?>Hello/saveData" method="post">
        <table>
            <tr>
                <td>Name</td>
                <td><input type="text" name="nm"/></td>
            </tr>
            <tr>
                <td>email</td>
                <td><input type="text" name="email"/></td>
            </tr>
            <tr>
                <td>password</td>
                <td><input type="text" name="pwd"/></td>
            </tr>
            <tr>
                <td colspan="2">
                    <input type="submit" value="submit"/>
                </td>
            </tr>
        </table>
        </form>
    </body>
</html>
<script type="text/javascript">
    $(document).ready(function(){
        //alert("hi");
        function loaduser(){
            url="<?=base_url()?>Hello/showUsers";
            $.ajax({
                url:url,
                success: function(result){
                    //alert(result);
                    $('#userlist').html(result);
                }
            });
        }
        loaduser();
        $("#frmAddUser").on("submit",function(){
            //alert("Form Submitted");
            var form = $(this);
            var url = form.attr("action");
            $.ajax({
                url:url,
                type:"POST",
                data:form.serialize(),
                success: function(result){
                    loaduser();
                }
            });
            loaduser();
            return false;
        });
    });
</script>